export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBfMnVt__RJieDb0yeFkJtURJW1y0DEyaU",
    authDomain: "angular-18-octubre-anabel.firebaseapp.com",
    projectId: "angular-18-octubre-anabel",
    storageBucket: "angular-18-octubre-anabel.appspot.com",
    messagingSenderId: "401163158216",
    appId: "1:401163158216:web:f3b1a2e054d5bc84641bfd"
  }
};