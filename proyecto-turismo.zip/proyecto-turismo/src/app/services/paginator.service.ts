import {Injectable} from '@angular/core';
import {MatPaginatorIntl} from '@angular/material/paginator';
import { TranslateService } from '@ngx-translate/core';
import {Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaginatorService implements MatPaginatorIntl {
  changes = new Subject<void>();

  // For internationalization, the `$localize` function from
  // the `@angular/localize` package can be used.
  //firstPageLabel = $localize`Inicio`;
  firstPageLabel = 'Inicio';
  itemsPerPageLabel = 'items por pagina:';
  lastPageLabel = 'Fin';

  // You can set labels to an arbitrary string too, or dynamically compute
  // it through other third-party internationalization libraries.
  nextPageLabel = 'Siguientes';
  previousPageLabel = 'Anteriores';

  /*
  constructor(private translateService: TranslateService){
    this.firstPageLabel = translateService.get('nav.home');
  }
  */

  getRangeLabel(page: number, pageSize: number, length: number): string {
    if (length === 0) {
      return 'Pagina 1 of 1';
    }
    const amountPages = Math.ceil(length / pageSize);
    return `Pagina ${page + 1} de ${amountPages}`;
  }
}