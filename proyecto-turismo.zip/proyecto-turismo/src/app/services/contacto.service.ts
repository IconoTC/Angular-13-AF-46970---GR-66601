import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  constructor() { }

  enviarContacto(contacto: any){
    console.log(contacto);
  }
}
