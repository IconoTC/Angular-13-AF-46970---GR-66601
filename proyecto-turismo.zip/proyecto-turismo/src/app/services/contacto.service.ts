import { AngularFirestore, DocumentReference } from '@angular/fire/firestore';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  private db = "/contactos";

  constructor(private angularFirestore: AngularFirestore) { }

  enviarContacto(contacto: any): Promise<DocumentReference<unknown>>{
    return this.angularFirestore.collection(this.db).add(contacto);
  }
}
