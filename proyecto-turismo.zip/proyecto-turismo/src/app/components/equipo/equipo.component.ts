import { Component, OnInit } from '@angular/core';
import { EquipoService } from 'src/app/services/equipo.service';

@Component({
  selector: 'app-equipo',
  templateUrl: './equipo.component.html',
  styleUrls: ['./equipo.component.css']
})
export class EquipoComponent implements OnInit {

  equipo: any[] = [];

  constructor(private equipoService: EquipoService) { 
    equipoService.getAll().subscribe(datos => {
      console.log(datos);
      // Este servicio de Harry Potter no tiene paginacion y me devuelve
      // 437 personajes.
      // Cojo solo los 20 primeros
      for(let i=0; i<20; i++){
        this.equipo.push(datos[i]);
      }
      console.log(this.equipo);
    });
  }

  ngOnInit(): void {
  }

}
