import { Component, OnInit } from '@angular/core';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  museos: Museo[] = [];

  constructor(private museosService: MuseosService) { 
    this.museos = museosService.getAll();
  }

  ngOnInit(): void {
  }

}
